This folder include  the jupyter notebook that is used for buiding up the models and conducting the experiments.
