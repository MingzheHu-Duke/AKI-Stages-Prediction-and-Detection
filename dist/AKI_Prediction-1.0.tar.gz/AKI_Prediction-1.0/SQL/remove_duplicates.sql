ALTER TABLE `my-project-mimic-iii-330123.MyMIMIC.raw_patient_data_recent`
DROP COLUMN icustay_id, DROP COLUMN aki_stage_creat, DROP COLUMN aki_stage_uo, DROP COLUMN subject_id, DROP COLUMN hadm_id, DROP COLUMN subject_id_1, DROP COLUMN hadm_id_1, DROP COLUMN icustay_id_2 
